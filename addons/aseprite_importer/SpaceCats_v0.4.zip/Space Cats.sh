#!/bin/sh
echo -ne '\033c\033]0;Space Cats\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Space Cats.x86_64" "$@"
